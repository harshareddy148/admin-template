import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-variables',
  templateUrl: './total-variables.component.html',
  styleUrls: ['./total-variables.component.css']
})
export class TotalVariablesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
